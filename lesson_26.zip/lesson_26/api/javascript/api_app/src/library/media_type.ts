export enum MediaType {
  UNKNOWN = 'unknown',
  BOOK = 'book',
  DVD = 'dvd',
  MAGAZINE = 'magazine',
  NEWSPAPER = 'newspaper',
}
