import { MediaItemResponse } from './media_item_response';

export interface GetMediaItemsResponse {
  items: MediaItemResponse[];
}
