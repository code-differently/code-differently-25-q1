import { MediaItemRequest } from './media_item_request';

export interface CreateMediaItemRequest {
  item: MediaItemRequest;
}
