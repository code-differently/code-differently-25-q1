package com.codedifferently.lesson26.library;

import java.util.List;
import java.util.UUID;

/** Represents a librarian of a library. */
public class Librarian extends LibraryGuestBase {
  public Librarian(String name, String email) {
    super(name, email);
  }

  @Override
  public String toString() {
    return "Librarian{" + "id='" + getEmail() + '\'' + ", name='" + getName() + '\'' + '}';
  }

  public MediaItem getItem(String id) {
    try {
      return getLibrary().findById(id);
    } catch (Exception e) {
      return null;
    }
  }

  public void removeItem(String id) {
    getLibrary().deleteById(id);
  }

  public MediaItem createItem(String title, String type, String genre, String author) {
    UUID id = UUID.randomUUID();
    MediaItem item =
        switch (type.toLowerCase()) {
          case "book" -> new Book(id, title, "isbn", List.of(author), 111);
          case "dvd" -> new Dvd(id, title);
          case "magazine" -> new Magazine(id, title);
          case "newspaper" -> new Newspaper(id, title);
          default -> throw new IllegalArgumentException("Invalid type");
        };
    getLibrary().addItem(item);
    return item;
  }
}
