package com.codedifferently.lesson26;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class Lesson26Test {

  @Test
  void testInstantiate() {
    assertThat(new Lesson26()).isNotNull();
  }
}
